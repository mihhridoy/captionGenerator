// ============================================================
//  lib/constants.dart
//  ⚠️  REPLACE all placeholder values before building
// ============================================================

class AppConstants {
  // ── Gemini AI ──────────────────────────────────────────────
  // Get yours at: https://aistudio.google.com/app/apikey
  static const String geminiApiKey = 'YOUR_GEMINI_API_KEY_HERE';
  static const String geminiModel   = 'gemini-1.5-flash';

  // ── AdMob ──────────────────────────────────────────────────
  // STEP 1: Go to https://admob.google.com
  // STEP 2: Apps → Add App → Android → Enter app name
  // STEP 3: Copy the App ID below (format: ca-app-pub-XXXX~XXXX)
  // STEP 4: Create 3 Ad Units: Banner, Interstitial, Rewarded
  // STEP 5: Copy each unit ID below

  static const String admobAppId =
      'ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX'; // ← YOUR AdMob App ID

  static const String bannerAdUnitId =
      'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX'; // ← Banner Ad Unit ID

  static const String interstitialAdUnitId =
      'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX'; // ← Interstitial Ad Unit ID

  static const String rewardedAdUnitId =
      'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX'; // ← Rewarded Ad Unit ID

  // ── TEST IDs (use these while developing) ─────────────────
  // Comment out the above and uncomment these for testing:
  // static const String admobAppId            = 'ca-app-pub-3940256099942544~3347511713';
  // static const String bannerAdUnitId        = 'ca-app-pub-3940256099942544/6300978111';
  // static const String interstitialAdUnitId  = 'ca-app-pub-3940256099942544/1033173712';
  // static const String rewardedAdUnitId      = 'ca-app-pub-3940256099942544/5224354917';

  // ── App Config ─────────────────────────────────────────────
  static const int freeDailyLimit          = 5;
  static const int interstitialEveryN      = 3; // show ad every 3rd generation
  static const int rewardedBonusCount      = 3; // bonus generations per rewarded ad

  // ── Package name (must match Firebase & Play Store) ────────
  static const String packageName = 'com.company.ainewsapp';
}
