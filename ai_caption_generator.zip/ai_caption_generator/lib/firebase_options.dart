// lib/firebase_options.dart
//
// ════════════════════════════════════════════════════════════
//  ⚠️  YOU MUST REPLACE THIS FILE WITH YOUR OWN
// ════════════════════════════════════════════════════════════
//
//  STEP-BY-STEP:
//  1. Open terminal in your project folder
//  2. Run:  dart pub global activate flutterfire_cli
//  3. Run:  flutterfire configure
//  4. Select your Firebase project: (the one you already created)
//  5. Select platform: Android
//  6. This file will be AUTO-REPLACED with your real credentials
//
//  The file below is a PLACEHOLDER so the project compiles.
//  It will NOT work until you run flutterfire configure.
// ════════════════════════════════════════════════════════════

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) throw UnsupportedError('Web not supported');
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      default:
        throw UnsupportedError('Unsupported platform');
    }
  }

  // ⚠️ REPLACE all values below after running: flutterfire configure
  static const FirebaseOptions android = FirebaseOptions(
    apiKey:            'YOUR-API-KEY-HERE',
    appId:             '1:000000000000:android:0000000000000000',
    messagingSenderId: '000000000000',
    projectId:         'your-firebase-project-id',
    storageBucket:     'your-firebase-project-id.appspot.com',
  );
}
