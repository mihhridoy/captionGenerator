// lib/screens/result_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:share_plus/share_plus.dart';
import '../services/firebase_service.dart';
import '../models/caption_model.dart';
import '../theme/app_theme.dart';
import '../widgets/common_widgets.dart';

class ResultScreen extends StatefulWidget {
  final CaptionModel caption;
  final VoidCallback onRegenerate;

  const ResultScreen({
    super.key,
    required this.caption,
    required this.onRegenerate,
  });

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  late bool _isFavorite;
  bool _copied = false;

  @override
  void initState() {
    super.initState();
    _isFavorite = widget.caption.isFavorite;
  }

  Color get _platformColor => switch (widget.caption.platform) {
    'instagram' => AppTheme.instagram,
    'tiktok'    => AppTheme.tiktok,
    'facebook'  => AppTheme.facebook,
    'twitter'   => AppTheme.twitter,
    _           => AppTheme.primary,
  };

  String get _platformEmoji => switch (widget.caption.platform) {
    'instagram' => '📸',
    'tiktok'    => '🎵',
    'facebook'  => '👥',
    'twitter'   => '𝕏',
    _           => '📱',
  };

  String get _fullText {
    final caption = widget.caption.captionText;
    if (widget.caption.hashtags.isEmpty) return caption;
    return '$caption\n\n${widget.caption.hashtags.join(' ')}';
  }

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: _fullText));
    setState(() => _copied = true);
    Fluttertoast.showToast(msg: '✅ Copied to clipboard!');
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) setState(() => _copied = false);
  }

  Future<void> _toggleFavorite() async {
    final newVal = !_isFavorite;
    setState(() => _isFavorite = newVal);
    await FirebaseService.toggleFavorite(widget.caption.captionId, newVal);
    Fluttertoast.showToast(
      msg: newVal ? '❤️ Saved to favorites!' : '💔 Removed from favorites',
    );
  }

  void _share() => Share.share(_fullText);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Caption'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_rounded),
            onPressed: _share,
            tooltip: 'Share',
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Platform badge
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: _platformColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(99),
                          border: Border.all(
                            color: _platformColor.withOpacity(0.3),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(_platformEmoji,
                              style: const TextStyle(fontSize: 14)),
                            const SizedBox(width: 6),
                            Text(
                              widget.caption.platform[0].toUpperCase() +
                                  widget.caption.platform.substring(1),
                              style: TextStyle(
                                fontSize: 13, fontWeight: FontWeight.w600,
                                color: _platformColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.border.withOpacity(0.5),
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          widget.caption.length[0].toUpperCase() +
                              widget.caption.length.substring(1),
                          style: const TextStyle(
                            fontSize: 12, color: AppTheme.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ).animate().fadeIn(duration: 300.ms),

                  const SizedBox(height: 16),

                  // Caption card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.cardShadow,
                          blurRadius: 20, offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.format_quote_rounded,
                              color: AppTheme.primary, size: 20),
                            const SizedBox(width: 6),
                            Text('Generated Caption',
                              style: TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w600,
                                color: AppTheme.primary,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              '${widget.caption.captionText.split(' ').length} words',
                              style: const TextStyle(
                                fontSize: 11, color: AppTheme.textHint,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        SelectableText(
                          widget.caption.captionText,
                          style: const TextStyle(
                            fontSize: 16, height: 1.65,
                            color: AppTheme.textPrimary,
                            fontFamily: 'Georgia',
                          ),
                        ),
                      ],
                    ),
                  ).animate(delay: 100.ms).fadeIn().slideY(begin: 0.2, end: 0),

                  // Hashtags
                  if (widget.caption.hashtags.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        const Icon(Icons.tag_rounded,
                          size: 16, color: AppTheme.primary),
                        const SizedBox(width: 6),
                        const Text('Hashtags',
                          style: TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Text('${widget.caption.hashtags.length}',
                            style: const TextStyle(
                              fontSize: 11, fontWeight: FontWeight.w600,
                              color: AppTheme.primary,
                            ),
                          ),
                        ),
                      ],
                    ).animate(delay: 200.ms).fadeIn(),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 6, runSpacing: 6,
                      children: widget.caption.hashtags.map((tag) =>
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(ClipboardData(text: tag));
                            Fluttertoast.showToast(msg: 'Copied $tag');
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.primary.withOpacity(0.07),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: AppTheme.primary.withOpacity(0.2),
                              ),
                            ),
                            child: Text(tag,
                              style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w500,
                                color: AppTheme.primary,
                              ),
                            ),
                          ),
                        ),
                      ).toList(),
                    ).animate(delay: 250.ms).fadeIn(),
                  ],

                  const SizedBox(height: 28),

                  // Action buttons row
                  Row(
                    children: [
                      Expanded(
                        child: _OutlineBtn(
                          icon: _copied
                              ? Icons.check_rounded
                              : Icons.copy_rounded,
                          label: _copied ? 'Copied!' : 'Copy All',
                          color: _copied ? AppTheme.success : AppTheme.primary,
                          onTap: _copy,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _OutlineBtn(
                          icon: _isFavorite
                              ? Icons.favorite_rounded
                              : Icons.favorite_border_rounded,
                          label: _isFavorite ? 'Saved!' : 'Save',
                          color: _isFavorite ? AppTheme.accent : AppTheme.primary,
                          onTap: _toggleFavorite,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _OutlineBtn(
                          icon: Icons.share_rounded,
                          label: 'Share',
                          color: AppTheme.primary,
                          onTap: _share,
                        ),
                      ),
                    ],
                  ).animate(delay: 300.ms).fadeIn().slideY(begin: 0.2, end: 0),

                  const SizedBox(height: 14),

                  // Regenerate
                  GradientButton(
                    label: '🔄  Regenerate Caption',
                    onTap: () {
                      Navigator.pop(context);
                      widget.onRegenerate();
                    },
                  ).animate(delay: 350.ms).fadeIn().slideY(begin: 0.2, end: 0),

                  const SizedBox(height: 16),
                  const BannerAdWidget(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OutlineBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _OutlineBtn({
    required this.icon, required this.label,
    required this.color, required this.onTap,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(
            fontSize: 11, fontWeight: FontWeight.w600, color: color,
          )),
        ],
      ),
    ),
  );
}
