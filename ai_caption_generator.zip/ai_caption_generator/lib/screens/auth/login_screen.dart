// lib/screens/auth/login_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../services/firebase_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../main/main_nav_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _emailCtrl    = TextEditingController();
  final _passCtrl     = TextEditingController();
  final _nameCtrl     = TextEditingController();
  final _confirmCtrl  = TextEditingController();
  bool _obscurePass   = true;
  bool _loading       = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _emailCtrl.dispose(); _passCtrl.dispose();
    _nameCtrl.dispose();  _confirmCtrl.dispose();
    super.dispose();
  }

  void _goHome() => Navigator.pushReplacement(
    context, MaterialPageRoute(builder: (_) => const MainNavScreen()),
  );

  void _toast(String msg) => Fluttertoast.showToast(
    msg: msg, backgroundColor: AppTheme.textPrimary, textColor: Colors.white,
  );

  Future<void> _signIn() async {
    if (_emailCtrl.text.isEmpty || _passCtrl.text.isEmpty) {
      _toast('Please fill all fields'); return;
    }
    setState(() => _loading = true);
    try {
      await FirebaseService.signInWithEmail(
        _emailCtrl.text.trim(), _passCtrl.text,
      );
      _goHome();
    } catch (e) {
      _toast('Sign in failed: ${_friendlyError(e.toString())}');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _signUp() async {
    if (_nameCtrl.text.isEmpty || _emailCtrl.text.isEmpty || _passCtrl.text.isEmpty) {
      _toast('Please fill all fields'); return;
    }
    if (_passCtrl.text != _confirmCtrl.text) {
      _toast('Passwords do not match'); return;
    }
    if (_passCtrl.text.length < 6) {
      _toast('Password must be at least 6 characters'); return;
    }
    setState(() => _loading = true);
    try {
      await FirebaseService.signUpWithEmail(
        _emailCtrl.text.trim(), _passCtrl.text, _nameCtrl.text.trim(),
      );
      _goHome();
    } catch (e) {
      _toast('Sign up failed: ${_friendlyError(e.toString())}');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _signInGoogle() async {
    setState(() => _loading = true);
    try {
      final cred = await FirebaseService.signInWithGoogle();
      if (cred != null) _goHome();
    } catch (e) {
      _toast('Google sign-in failed');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _friendlyError(String raw) {
    if (raw.contains('user-not-found'))   return 'No account with that email';
    if (raw.contains('wrong-password'))   return 'Incorrect password';
    if (raw.contains('email-already'))    return 'Email already in use';
    if (raw.contains('network-request'))  return 'No internet connection';
    return 'Please try again';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              const SizedBox(height: 40),
              // Logo
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  gradient: primaryGradient,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(Icons.auto_awesome_rounded,
                  size: 36, color: Colors.white),
              )
              .animate().scale(duration: 500.ms, curve: Curves.elasticOut),

              const SizedBox(height: 20),
              Text('AI Caption Generator',
                style: Theme.of(context).textTheme.displayMedium,
              ).animate(delay: 200.ms).fadeIn().slideY(begin: 0.3, end: 0),

              Text('Create viral captions in seconds',
                style: Theme.of(context).textTheme.bodyMedium,
              ).animate(delay: 300.ms).fadeIn(),

              const SizedBox(height: 36),

              // Tab bar
              Container(
                decoration: BoxDecoration(
                  color: AppTheme.border.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    color: AppTheme.primary,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  labelColor: Colors.white,
                  unselectedLabelColor: AppTheme.textSecondary,
                  dividerColor: Colors.transparent,
                  tabs: const [
                    Tab(text: 'Sign In'),
                    Tab(text: 'Sign Up'),
                  ],
                ),
              ).animate(delay: 400.ms).fadeIn(),

              const SizedBox(height: 24),

              SizedBox(
                height: 380,
                child: TabBarView(
                  controller: _tabController,
                  children: [_buildSignIn(), _buildSignUp()],
                ),
              ),

              const SizedBox(height: 16),
              Row(children: [
                const Expanded(child: Divider()),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text('or', style: Theme.of(context).textTheme.bodyMedium),
                ),
                const Expanded(child: Divider()),
              ]),
              const SizedBox(height: 16),

              // Google Sign In
              OutlinedButton.icon(
                onPressed: _loading ? null : _signInGoogle,
                icon: const Text('G', style: TextStyle(
                  fontSize: 18, fontWeight: FontWeight.w700,
                  color: Color(0xFF4285F4),
                )),
                label: const Text('Continue with Google'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 52),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  side: const BorderSide(color: AppTheme.border),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSignIn() => Column(
    children: [
      TextField(
        controller: _emailCtrl,
        keyboardType: TextInputType.emailAddress,
        decoration: const InputDecoration(
          hintText: 'Email address',
          prefixIcon: Icon(Icons.email_outlined, color: AppTheme.textHint),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _passCtrl,
        obscureText: _obscurePass,
        decoration: InputDecoration(
          hintText: 'Password',
          prefixIcon: const Icon(Icons.lock_outline, color: AppTheme.textHint),
          suffixIcon: IconButton(
            icon: Icon(
              _obscurePass ? Icons.visibility_outlined : Icons.visibility_off_outlined,
              color: AppTheme.textHint,
            ),
            onPressed: () => setState(() => _obscurePass = !_obscurePass),
          ),
        ),
      ),
      Align(
        alignment: Alignment.centerRight,
        child: TextButton(
          onPressed: () => _showForgotPassword(),
          child: const Text('Forgot password?',
            style: TextStyle(color: AppTheme.primary, fontSize: 13),
          ),
        ),
      ),
      const SizedBox(height: 8),
      GradientButton(
        label: 'Sign In',
        icon: Icons.login_rounded,
        onTap: _signIn,
        isLoading: _loading,
      ),
    ],
  );

  Widget _buildSignUp() => Column(
    children: [
      TextField(
        controller: _nameCtrl,
        decoration: const InputDecoration(
          hintText: 'Your name',
          prefixIcon: Icon(Icons.person_outline, color: AppTheme.textHint),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _emailCtrl,
        keyboardType: TextInputType.emailAddress,
        decoration: const InputDecoration(
          hintText: 'Email address',
          prefixIcon: Icon(Icons.email_outlined, color: AppTheme.textHint),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _passCtrl,
        obscureText: _obscurePass,
        decoration: InputDecoration(
          hintText: 'Password (min 6 chars)',
          prefixIcon: const Icon(Icons.lock_outline, color: AppTheme.textHint),
          suffixIcon: IconButton(
            icon: Icon(
              _obscurePass ? Icons.visibility_outlined : Icons.visibility_off_outlined,
              color: AppTheme.textHint,
            ),
            onPressed: () => setState(() => _obscurePass = !_obscurePass),
          ),
        ),
      ),
      const SizedBox(height: 12),
      TextField(
        controller: _confirmCtrl,
        obscureText: true,
        decoration: const InputDecoration(
          hintText: 'Confirm password',
          prefixIcon: Icon(Icons.lock_outline, color: AppTheme.textHint),
        ),
      ),
      const SizedBox(height: 20),
      GradientButton(
        label: 'Create Account',
        icon: Icons.person_add_rounded,
        onTap: _signUp,
        isLoading: _loading,
      ),
    ],
  );

  void _showForgotPassword() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Reset Password'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.emailAddress,
          decoration: const InputDecoration(hintText: 'Enter your email'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (ctrl.text.isNotEmpty) {
                await FirebaseService.resetPassword(ctrl.text.trim());
                if (context.mounted) {
                  Navigator.pop(context);
                  _toast('Reset email sent!');
                }
              }
            },
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }
}
