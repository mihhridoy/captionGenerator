// lib/screens/splash_screen.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../theme/app_theme.dart';
import 'auth/login_screen.dart';
import 'main/main_nav_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigate();
  }

  Future<void> _navigate() async {
    await Future.delayed(const Duration(milliseconds: 2200));
    if (!mounted) return;
    final user = FirebaseAuth.instance.currentUser;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => user != null ? const MainNavScreen() : const LoginScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: primaryGradient),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Logo icon
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(28),
                ),
                child: const Icon(Icons.auto_awesome_rounded,
                  size: 52, color: Colors.white),
              )
              .animate()
              .scale(duration: 600.ms, curve: Curves.elasticOut),

              const SizedBox(height: 24),

              const Text('AI Caption Generator',
                style: TextStyle(
                  color: Colors.white, fontSize: 26,
                  fontWeight: FontWeight.w700, letterSpacing: -0.5,
                ),
              )
              .animate(delay: 300.ms)
              .fadeIn(duration: 500.ms)
              .slideY(begin: 0.3, end: 0),

              const SizedBox(height: 8),

              Text('Hashtags & Bio',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.75), fontSize: 15,
                ),
              )
              .animate(delay: 500.ms)
              .fadeIn(duration: 500.ms),

              const SizedBox(height: 60),

              SizedBox(
                width: 28, height: 28,
                child: CircularProgressIndicator(
                  color: Colors.white.withOpacity(0.6),
                  strokeWidth: 2.5,
                ),
              )
              .animate(delay: 800.ms)
              .fadeIn(duration: 400.ms),
            ],
          ),
        ),
      ),
    );
  }
}
