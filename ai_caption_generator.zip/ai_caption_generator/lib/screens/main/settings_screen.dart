// lib/screens/main/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../services/firebase_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../auth/login_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _user = FirebaseAuth.instance.currentUser;

  Future<void> _signOut() async {
    await FirebaseService.signOut();
    if (!mounted) return;
    Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.only(
        left: 24, right: 24, top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Container(
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: AppTheme.border,
              borderRadius: BorderRadius.circular(99),
            ),
          ),
          const SizedBox(height: 24),

          // Avatar
          CircleAvatar(
            radius: 36,
            backgroundColor: AppTheme.primary.withOpacity(0.15),
            backgroundImage: _user?.photoURL != null
                ? NetworkImage(_user!.photoURL!)
                : null,
            child: _user?.photoURL == null
                ? Text(
                    (_user?.displayName ?? 'U')[0].toUpperCase(),
                    style: const TextStyle(
                      fontSize: 28, fontWeight: FontWeight.w700,
                      color: AppTheme.primary,
                    ),
                  )
                : null,
          ),
          const SizedBox(height: 12),
          Text(
            _user?.displayName ?? 'User',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          Text(
            _user?.email ?? '',
            style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: AppTheme.warning.withOpacity(0.12),
              borderRadius: BorderRadius.circular(99),
            ),
            child: const Text('Free Plan',
              style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.w600,
                color: AppTheme.warning,
              ),
            ),
          ),

          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 8),

          // Settings items
          _SettingItem(
            icon: Icons.notifications_outlined,
            label: 'Notifications',
            onTap: () => Fluttertoast.showToast(msg: 'Coming soon!'),
          ),
          _SettingItem(
            icon: Icons.privacy_tip_outlined,
            label: 'Privacy Policy',
            onTap: () => Fluttertoast.showToast(msg: 'Opening...'),
          ),
          _SettingItem(
            icon: Icons.star_outline_rounded,
            label: 'Rate the App',
            onTap: () => Fluttertoast.showToast(msg: 'Thank you! 🌟'),
          ),
          _SettingItem(
            icon: Icons.info_outline_rounded,
            label: 'App Version',
            trailing: const Text('1.0.0',
              style: TextStyle(fontSize: 13, color: AppTheme.textHint)),
            onTap: () {},
          ),

          const SizedBox(height: 16),

          GradientButton(
            label: 'Sign Out',
            gradient: accentGradient,
            icon: Icons.logout_rounded,
            onTap: _signOut,
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}

class _SettingItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final Widget? trailing;
  final VoidCallback onTap;
  const _SettingItem({
    required this.icon, required this.label,
    required this.onTap, this.trailing,
  });

  @override
  Widget build(BuildContext context) => ListTile(
    contentPadding: EdgeInsets.zero,
    leading: Container(
      width: 38, height: 38,
      decoration: BoxDecoration(
        color: AppTheme.background,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(icon, size: 20, color: AppTheme.textSecondary),
    ),
    title: Text(label, style: const TextStyle(fontSize: 14)),
    trailing: trailing ?? const Icon(
      Icons.chevron_right_rounded, color: AppTheme.textHint,
    ),
    onTap: onTap,
  );
}
