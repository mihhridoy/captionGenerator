// lib/screens/main/saved_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../services/firebase_service.dart';
import '../../models/caption_model.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common_widgets.dart';

class SavedScreen extends StatelessWidget {
  const SavedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('❤️ Saved Captions')),
      body: StreamBuilder<List<CaptionModel>>(
        stream: FirebaseService.savedCaptionsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final captions = snapshot.data ?? [];
          if (captions.isEmpty) {
            return _EmptyState(
              icon: Icons.favorite_border_rounded,
              title: 'No saved captions yet',
              subtitle: 'Tap the heart icon on any caption\nto save it here',
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: captions.length,
            itemBuilder: (_, i) {
              final c = captions[i];
              return CaptionListCard(
                captionText:      c.captionText,
                platform:         c.platform,
                topic:            c.topic,
                isFavorite:       c.isFavorite,
                generatedAt:      c.generatedAt,
                onCopy: () {
                  final text = c.includeHashtags && c.hashtags.isNotEmpty
                      ? '${c.captionText}\n\n${c.hashtags.join(' ')}'
                      : c.captionText;
                  Clipboard.setData(ClipboardData(text: text));
                  Fluttertoast.showToast(msg: '✅ Copied!');
                },
                onToggleFavorite: () =>
                    FirebaseService.toggleFavorite(c.captionId, false),
              );
            },
          );
        },
      ),
    );
  }
}


// ══════════════════════════════════════════════════════════
//  HISTORY SCREEN
// ══════════════════════════════════════════════════════════

// lib/screens/main/history_screen.dart  (same file for brevity)
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🕐 History')),
      body: StreamBuilder<List<CaptionModel>>(
        stream: FirebaseService.historyStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final captions = snapshot.data ?? [];
          if (captions.isEmpty) {
            return _EmptyState(
              icon: Icons.history_rounded,
              title: 'No history yet',
              subtitle: 'Your generated captions\nwill appear here',
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: captions.length,
            itemBuilder: (_, i) {
              final c = captions[i];
              return CaptionListCard(
                captionText:      c.captionText,
                platform:         c.platform,
                topic:            c.topic,
                isFavorite:       c.isFavorite,
                generatedAt:      c.generatedAt,
                onCopy: () {
                  final text = c.includeHashtags && c.hashtags.isNotEmpty
                      ? '${c.captionText}\n\n${c.hashtags.join(' ')}'
                      : c.captionText;
                  Clipboard.setData(ClipboardData(text: text));
                  Fluttertoast.showToast(msg: '✅ Copied!');
                },
                onToggleFavorite: () =>
                    FirebaseService.toggleFavorite(c.captionId, !c.isFavorite),
                onDelete: () => _confirmDelete(context, c.captionId),
              );
            },
          );
        },
      ),
    );
  }

  void _confirmDelete(BuildContext context, String id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete Caption?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () {
              FirebaseService.deleteCaption(id);
              Navigator.pop(context);
              Fluttertoast.showToast(msg: 'Deleted');
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}

// ── Shared empty state widget ──────────────────────────────
class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const _EmptyState({
    required this.icon, required this.title, required this.subtitle,
  });

  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 64, color: AppTheme.textHint),
        const SizedBox(height: 16),
        Text(title,
          style: const TextStyle(
            fontSize: 18, fontWeight: FontWeight.w600, color: AppTheme.textPrimary,
          ),
        ),
        const SizedBox(height: 8),
        Text(subtitle,
          textAlign: TextAlign.center,
          style: const TextStyle(color: AppTheme.textSecondary, height: 1.5),
        ),
      ],
    ),
  );
}
