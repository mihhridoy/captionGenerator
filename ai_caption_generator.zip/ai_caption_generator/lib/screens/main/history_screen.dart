// lib/screens/main/history_screen.dart
// HistoryScreen is defined in saved_screen.dart for convenience.
// This file re-exports it so imports work cleanly.
export 'saved_screen.dart' show HistoryScreen;
