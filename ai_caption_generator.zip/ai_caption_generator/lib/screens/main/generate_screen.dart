// lib/screens/main/generate_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../services/firebase_service.dart';
import '../../services/gemini_service.dart';
import '../../services/admob_service.dart';
import '../../models/caption_model.dart';
import '../../models/user_model.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common_widgets.dart';
import '../result_screen.dart';

class GenerateScreen extends StatefulWidget {
  const GenerateScreen({super.key});

  @override
  State<GenerateScreen> createState() => _GenerateScreenState();
}

class _GenerateScreenState extends State<GenerateScreen> {
  final _topicCtrl = TextEditingController();

  String _platform        = 'instagram';
  String _length          = 'medium';
  bool   _includeHashtags = true;
  bool   _loading         = false;
  UserModel? _user;

  final _platforms = [
    {'id': 'instagram', 'label': 'Instagram', 'emoji': '📸', 'color': AppTheme.instagram},
    {'id': 'tiktok',    'label': 'TikTok',    'emoji': '🎵', 'color': AppTheme.tiktok},
    {'id': 'facebook',  'label': 'Facebook',  'emoji': '👥', 'color': AppTheme.facebook},
    {'id': 'twitter',   'label': 'Twitter/X', 'emoji': '𝕏',  'color': AppTheme.twitter},
  ];

  final _lengths = [
    {'id': 'short',  'label': 'Short',  'sub': '< 20 words'},
    {'id': 'medium', 'label': 'Medium', 'sub': '20–50 words'},
    {'id': 'long',   'label': 'Long',   'sub': '50+ words'},
  ];

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  @override
  void dispose() {
    _topicCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadUser() async {
    final user = await FirebaseService.getUser();
    if (mounted) setState(() => _user = user);
  }

  Future<void> _generate() async {
    final topic = _topicCtrl.text.trim();
    if (topic.isEmpty) {
      Fluttertoast.showToast(msg: 'Please enter a topic first 💡');
      return;
    }

    // Refresh user to get latest count
    await _loadUser();

    if (_user != null && !_user!.canGenerate) {
      _showLimitDialog();
      return;
    }

    setState(() => _loading = true);

    try {
      final result = await GeminiService.generateCaption(
        topic: topic, platform: _platform,
        length: _length, includeHashtags: _includeHashtags,
      );

      final caption = CaptionModel(
        captionId:       '',
        topic:           topic,
        platform:        _platform,
        length:          _length,
        includeHashtags: _includeHashtags,
        captionText:     result['caption'] as String,
        hashtags:        List<String>.from(result['hashtags'] as List),
        generatedAt:     DateTime.now(),
      );

      // Save to Firestore and get the document ID back
      final docId = await FirebaseService.saveCaption(caption);
      await FirebaseService.incrementDailyCount();

      // Track for interstitial ad
      AdMobService.onGeneration();

      if (!mounted) return;

      // Navigate to result
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(
            caption:   caption.copyWith(captionId: docId),
            onRegenerate: _generate,
          ),
        ),
      );

      // Refresh user after coming back
      _loadUser();

    } catch (e) {
      Fluttertoast.showToast(
        msg: 'Error: ${e.toString().replaceAll('Exception: ', '')}',
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showLimitDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _LimitSheet(
        onWatchAd: () {
          Navigator.pop(context);
          if (AdMobService.isRewardedReady) {
            AdMobService.showRewarded(onRewarded: () async {
              await FirebaseService.addBonusGenerations(3);
              await _loadUser();
              Fluttertoast.showToast(msg: '🎉 You earned 3 bonus captions!');
            });
          } else {
            Fluttertoast.showToast(msg: 'Ad not ready, try again in a moment');
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('✨ AI Caption Generator'),
        actions: [
          if (_user != null)
            Container(
              margin: const EdgeInsets.only(right: 16),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: _user!.remaining > 0
                    ? AppTheme.success.withOpacity(0.12)
                    : AppTheme.accent.withOpacity(0.12),
                borderRadius: BorderRadius.circular(99),
              ),
              child: Text(
                _user!.isPremium ? '∞ Unlimited' : '${_user!.remaining} left',
                style: TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w600,
                  color: _user!.remaining > 0 ? AppTheme.success : AppTheme.accent,
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          const BannerAdWidget(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Topic Input
                  _SectionLabel(label: '💡 What\'s your caption about?', index: 0),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _topicCtrl,
                    maxLines: 2,
                    maxLength: 100,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: const InputDecoration(
                      hintText: 'e.g. morning workout, travel vlog, food recipe...',
                      counterStyle: TextStyle(fontSize: 11, color: AppTheme.textHint),
                    ),
                  ).animate(delay: 100.ms).fadeIn().slideY(begin: 0.2, end: 0),

                  const SizedBox(height: 24),

                  // Platform
                  _SectionLabel(label: '📱 Platform', index: 1),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 10, runSpacing: 10,
                    children: _platforms.map((p) => PlatformChip(
                      label:         p['label'] as String,
                      emoji:         p['emoji'] as String,
                      selected:      _platform == p['id'],
                      platformColor: p['color'] as Color,
                      onTap: () => setState(() => _platform = p['id'] as String),
                    )).toList(),
                  ).animate(delay: 150.ms).fadeIn().slideY(begin: 0.2, end: 0),

                  const SizedBox(height: 24),

                  // Length
                  _SectionLabel(label: '📏 Caption Length', index: 2),
                  const SizedBox(height: 10),
                  Row(
                    children: _lengths.map((l) => Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(
                          right: l['id'] != 'long' ? 8.0 : 0,
                        ),
                        child: LengthChip(
                          label:    l['label'] as String,
                          sublabel: l['sub'] as String,
                          selected: _length == l['id'],
                          onTap: () => setState(() => _length = l['id'] as String),
                        ),
                      ),
                    )).toList(),
                  ).animate(delay: 200.ms).fadeIn().slideY(begin: 0.2, end: 0),

                  const SizedBox(height: 24),

                  // Hashtags toggle
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 38, height: 38,
                          decoration: BoxDecoration(
                            color: AppTheme.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.tag_rounded,
                            color: AppTheme.primary, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Include Hashtags',
                                style: TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.w600,
                                  color: AppTheme.textPrimary,
                                ),
                              ),
                              Text(
                                _includeHashtags ? '12 hashtags will be added' : 'No hashtags',
                                style: const TextStyle(
                                  fontSize: 12, color: AppTheme.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Switch.adaptive(
                          value: _includeHashtags,
                          onChanged: (v) => setState(() => _includeHashtags = v),
                          activeColor: AppTheme.primary,
                        ),
                      ],
                    ),
                  ).animate(delay: 250.ms).fadeIn().slideY(begin: 0.2, end: 0),

                  const SizedBox(height: 32),

                  // Generate button
                  GradientButton(
                    label: _loading ? 'Generating...' : '✨ Generate Caption',
                    isLoading: _loading,
                    onTap: _generate,
                  ).animate(delay: 300.ms).fadeIn().slideY(begin: 0.3, end: 0),

                  const SizedBox(height: 8),

                  Center(
                    child: Text(
                      'Powered by Google Gemini AI',
                      style: TextStyle(fontSize: 11, color: AppTheme.textHint),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  final int index;
  const _SectionLabel({required this.label, required this.index});

  @override
  Widget build(BuildContext context) => Text(label,
    style: const TextStyle(
      fontSize: 14, fontWeight: FontWeight.w600, color: AppTheme.textPrimary,
    ),
  ).animate(delay: Duration(milliseconds: 50 * index)).fadeIn();
}

// ── Limit bottom sheet ─────────────────────────────────────
class _LimitSheet extends StatelessWidget {
  final VoidCallback onWatchAd;
  const _LimitSheet({required this.onWatchAd});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 40, height: 4, decoration: BoxDecoration(
            color: AppTheme.border, borderRadius: BorderRadius.circular(99),
          )),
          const SizedBox(height: 24),
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(
              color: AppTheme.accent.withOpacity(0.1),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(Icons.lock_clock_rounded,
              size: 32, color: AppTheme.accent),
          ),
          const SizedBox(height: 16),
          const Text("Daily Limit Reached",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          const Text(
            "You've used all your free captions for today.\nWatch a short ad to get 3 more captions!",
            textAlign: TextAlign.center,
            style: TextStyle(color: AppTheme.textSecondary, height: 1.5),
          ),
          const SizedBox(height: 24),
          GradientButton(
            label: '▶  Watch Ad — Get 3 Captions',
            gradient: accentGradient,
            onTap: onWatchAd,
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Maybe Tomorrow',
              style: TextStyle(color: AppTheme.textSecondary)),
          ),
          SizedBox(height: MediaQuery.of(context).viewInsets.bottom),
        ],
      ),
    );
  }
}

// ── CaptionModel helper extension ─────────────────────────
extension CaptionCopy on CaptionModel {
  CaptionModel copyWith({String? captionId}) => CaptionModel(
    captionId:       captionId ?? this.captionId,
    topic:           topic,
    platform:        platform,
    length:          length,
    includeHashtags: includeHashtags,
    captionText:     captionText,
    hashtags:        hashtags,
    isFavorite:      isFavorite,
    generatedAt:     generatedAt,
  );
}
