// lib/services/admob_service.dart
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../constants.dart';

class AdMobService {
  static InterstitialAd? _interstitialAd;
  static RewardedAd? _rewardedAd;
  static int _generationCount = 0;

  // ── Initialize AdMob (call once in main.dart) ──────────────
  static Future<void> initialize() async {
    await MobileAds.instance.initialize();
    _loadInterstitial();
    _loadRewarded();
  }

  // ══════════════════════════════════════════════════════════
  //  BANNER
  // ══════════════════════════════════════════════════════════

  static BannerAd createBanner() => BannerAd(
    adUnitId: AppConstants.bannerAdUnitId,
    size:     AdSize.banner,
    request:  const AdRequest(),
    listener: BannerAdListener(
      onAdFailedToLoad: (ad, error) => ad.dispose(),
    ),
  );

  // ══════════════════════════════════════════════════════════
  //  INTERSTITIAL
  // ══════════════════════════════════════════════════════════

  static void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: AppConstants.interstitialAdUnitId,
      request:  const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded:       (ad) => _interstitialAd = ad,
        onAdFailedToLoad: (error) => _interstitialAd = null,
      ),
    );
  }

  /// Call after every caption generation.
  /// Shows interstitial every Nth generation.
  static void onGeneration() {
    _generationCount++;
    if (_generationCount % AppConstants.interstitialEveryN == 0) {
      showInterstitial();
    }
  }

  static void showInterstitial() {
    if (_interstitialAd == null) return;
    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _interstitialAd = null;
        _loadInterstitial(); // preload next
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _interstitialAd = null;
        _loadInterstitial();
      },
    );
    _interstitialAd!.show();
    _interstitialAd = null;
  }

  // ══════════════════════════════════════════════════════════
  //  REWARDED
  // ══════════════════════════════════════════════════════════

  static void _loadRewarded() {
    RewardedAd.load(
      adUnitId: AppConstants.rewardedAdUnitId,
      request:  const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded:       (ad) => _rewardedAd = ad,
        onAdFailedToLoad: (error) => _rewardedAd = null,
      ),
    );
  }

  static bool get isRewardedReady => _rewardedAd != null;

  /// Shows rewarded ad. Calls [onRewarded] if user completes it.
  static void showRewarded({required VoidCallback onRewarded}) {
    if (_rewardedAd == null) return;
    _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _rewardedAd = null;
        _loadRewarded();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _rewardedAd = null;
        _loadRewarded();
      },
    );
    _rewardedAd!.show(onUserEarnedReward: (_, __) => onRewarded());
    _rewardedAd = null;
  }
}
