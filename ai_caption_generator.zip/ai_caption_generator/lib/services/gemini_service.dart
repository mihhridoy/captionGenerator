// lib/services/gemini_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants.dart';

class GeminiService {
  static const String _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  // ── Build the dynamic prompt ───────────────────────────────
  static String _buildPrompt({
    required String topic,
    required String platform,
    required String length,
    required bool includeHashtags,
  }) {
    final platformRules = {
      'instagram': 'emotional, storytelling tone, use 3-5 relevant emojis naturally in the text, make it visually appealing',
      'tiktok':    'trendy, punchy, start with a hook like "POV:" or a question, use Gen-Z friendly language and 1-3 emojis',
      'facebook':  'warm, community-focused, conversational tone, encourage engagement with a question at the end',
      'twitter':   'witty, concise, punchy, no hashtags inside the caption text itself, under 280 characters total',
    };

    final lengthRules = {
      'short':  'under 20 words total, make every word count',
      'medium': '20 to 50 words, develop one key idea clearly',
      'long':   '50 to 100 words, tell a mini story or provide real value',
    };

    final hashtagInstruction = includeHashtags
        ? '\n\nAfter the caption, on a completely new line, add exactly 12 relevant hashtags starting with #. Mix popular (#fitness) and niche (#morningworkoutroutine) hashtags.'
        : '';

    return '''You are an expert social media copywriter specializing in viral content for ${platform.toUpperCase()}.

Write a ${lengthRules[length]} caption about this topic: "$topic"

Platform style rules: ${platformRules[platform]}

CRITICAL RULES:
- Return ONLY the caption text, nothing else
- No preamble like "Here is your caption:"
- No quotation marks around the caption
- Make it feel authentic, not AI-generated$hashtagInstruction''';
  }

  // ── Main generate function ─────────────────────────────────
  static Future<Map<String, dynamic>> generateCaption({
    required String topic,
    required String platform,
    required String length,
    required bool includeHashtags,
  }) async {
    final prompt = _buildPrompt(
      topic: topic,
      platform: platform,
      length: length,
      includeHashtags: includeHashtags,
    );

    final url = Uri.parse(
      '$_baseUrl/${AppConstants.geminiModel}:generateContent'
      '?key=${AppConstants.geminiApiKey}',
    );

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'contents': [
            {'parts': [{'text': prompt}]}
          ],
          'generationConfig': {
            'temperature':     0.9,
            'topK':            40,
            'topP':            0.95,
            'maxOutputTokens': 600,
          },
          'safetySettings': [
            {'category': 'HARM_CATEGORY_HARASSMENT',        'threshold': 'BLOCK_MEDIUM_AND_ABOVE'},
            {'category': 'HARM_CATEGORY_HATE_SPEECH',       'threshold': 'BLOCK_MEDIUM_AND_ABOVE'},
            {'category': 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold': 'BLOCK_MEDIUM_AND_ABOVE'},
          ],
        }),
      ).timeout(const Duration(seconds: 20));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final rawText = data['candidates'][0]['content']['parts'][0]['text'] as String;
        return _parseResponse(rawText, includeHashtags);
      } else {
        final err = jsonDecode(response.body);
        throw Exception(err['error']['message'] ?? 'API error ${response.statusCode}');
      }
    } on Exception {
      rethrow;
    }
  }

  // ── Parse AI response into caption + hashtags ──────────────
  static Map<String, dynamic> _parseResponse(String rawText, bool includeHashtags) {
    if (!includeHashtags) {
      return {'caption': rawText.trim(), 'hashtags': <String>[]};
    }

    final lines = rawText.trim().split('\n');
    final captionLines  = <String>[];
    final hashtagLines  = <String>[];

    for (final line in lines) {
      final trimmed = line.trim();
      if (trimmed.isEmpty) continue;

      // A "hashtag line" has more than half its words starting with #
      final words = trimmed.split(' ');
      final hashCount = words.where((w) => w.startsWith('#')).length;
      if (hashCount > words.length / 2) {
        hashtagLines.add(trimmed);
      } else {
        captionLines.add(trimmed);
      }
    }

    // Extract individual hashtags
    final hashtags = hashtagLines
        .join(' ')
        .split(' ')
        .where((w) => w.startsWith('#') && w.length > 1)
        .map((w) => w.replaceAll(RegExp(r'[^#\w]'), ''))
        .toList();

    return {
      'caption':  captionLines.join('\n').trim(),
      'hashtags': hashtags,
    };
  }
}
