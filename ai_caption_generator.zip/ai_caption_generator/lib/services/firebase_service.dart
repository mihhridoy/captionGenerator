// lib/services/firebase_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../models/user_model.dart';
import '../models/caption_model.dart';
import '../constants.dart';

class FirebaseService {
  static final _auth      = FirebaseAuth.instance;
  static final _firestore = FirebaseFirestore.instance;
  static final _googleSignIn = GoogleSignIn();

  // ── Current user shortcut ──────────────────────────────────
  static User? get currentUser => _auth.currentUser;
  static String get uid => _auth.currentUser!.uid;

  // ══════════════════════════════════════════════════════════
  //  AUTH
  // ══════════════════════════════════════════════════════════

  static Future<UserCredential> signInWithEmail(String email, String password) =>
      _auth.signInWithEmailAndPassword(email: email, password: password);

  static Future<UserCredential> signUpWithEmail(
    String email, String password, String name,
  ) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email, password: password,
    );
    await cred.user!.updateDisplayName(name);
    await _createUserDoc(cred.user!, name);
    return cred;
  }

  static Future<UserCredential?> signInWithGoogle() async {
    final googleUser = await _googleSignIn.signIn();
    if (googleUser == null) return null;
    final googleAuth = await googleUser.authentication;
    final cred = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken:     googleAuth.idToken,
    );
    final userCred = await _auth.signInWithCredential(cred);
    // Create doc only on first sign-in
    final doc = await _firestore.collection('users').doc(userCred.user!.uid).get();
    if (!doc.exists) {
      await _createUserDoc(
        userCred.user!,
        userCred.user!.displayName ?? 'User',
      );
    }
    return userCred;
  }

  static Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }

  static Future<void> resetPassword(String email) =>
      _auth.sendPasswordResetEmail(email: email);

  // ── Create user document in Firestore ─────────────────────
  static Future<void> _createUserDoc(User user, String name) =>
      _firestore.collection('users').doc(user.uid).set(UserModel(
        uid:         user.uid,
        email:       user.email ?? '',
        displayName: name,
        createdAt:   DateTime.now(),
      ).toMap());

  // ══════════════════════════════════════════════════════════
  //  USER DATA
  // ══════════════════════════════════════════════════════════

  static Future<UserModel?> getUser() async {
    final doc = await _firestore.collection('users').doc(uid).get();
    if (!doc.exists) return null;
    final user = UserModel.fromFirestore(doc);
    // Reset daily count if it's a new day
    await _resetDailyCountIfNeeded(user);
    return user;
  }

  static Future<void> _resetDailyCountIfNeeded(UserModel user) async {
    final now   = DateTime.now();
    final reset = user.dailyCountReset;
    if (reset == null ||
        reset.year != now.year ||
        reset.month != now.month ||
        reset.day != now.day) {
      await _firestore.collection('users').doc(uid).update({
        'dailyCount':      0,
        'dailyCountReset': Timestamp.fromDate(now),
      });
    }
  }

  static Future<void> incrementDailyCount() =>
      _firestore.collection('users').doc(uid).update({
        'dailyCount': FieldValue.increment(1),
      });

  static Future<void> addBonusGenerations(int count) =>
      _firestore.collection('users').doc(uid).update({
        'bonusCount': FieldValue.increment(count),
      });

  // ══════════════════════════════════════════════════════════
  //  CAPTIONS
  // ══════════════════════════════════════════════════════════

  static CollectionReference get _captionsRef =>
      _firestore.collection('users').doc(uid).collection('captions');

  static Future<String> saveCaption(CaptionModel caption) async {
    final doc = await _captionsRef.add(caption.toMap());
    return doc.id;
  }

  static Future<void> toggleFavorite(String captionId, bool isFavorite) =>
      _captionsRef.doc(captionId).update({'isFavorite': isFavorite});

  static Future<void> deleteCaption(String captionId) =>
      _captionsRef.doc(captionId).delete();

  // ── Saved captions stream ──────────────────────────────────
  static Stream<List<CaptionModel>> savedCaptionsStream() =>
      _captionsRef
          .where('isFavorite', isEqualTo: true)
          .orderBy('generatedAt', descending: true)
          .snapshots()
          .map((s) => s.docs.map(CaptionModel.fromFirestore).toList());

  // ── History stream ─────────────────────────────────────────
  static Stream<List<CaptionModel>> historyStream() =>
      _captionsRef
          .orderBy('generatedAt', descending: true)
          .limit(50)
          .snapshots()
          .map((s) => s.docs.map(CaptionModel.fromFirestore).toList());

  // ── Free limit from app_config (fallback to constant) ──────
  static Future<int> getFreeLimit() async {
    try {
      final doc = await _firestore.collection('app_config').doc('settings').get();
      if (doc.exists) return (doc.data() as Map)['freeDailyLimit'] ?? AppConstants.freeDailyLimit;
    } catch (_) {}
    return AppConstants.freeDailyLimit;
  }
}
