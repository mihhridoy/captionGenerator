// lib/widgets/common_widgets.dart
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../services/admob_service.dart';
import '../theme/app_theme.dart';

// ══════════════════════════════════════════════════════════
//  BANNER AD WIDGET
// ══════════════════════════════════════════════════════════
class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  BannerAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _ad = AdMobService.createBanner()
      ..load().then((_) {
        if (mounted) setState(() => _loaded = true);
      });
  }

  @override
  void dispose() {
    _ad?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _ad == null) return const SizedBox.shrink();
    return SizedBox(
      height: _ad!.size.height.toDouble(),
      width:  _ad!.size.width.toDouble(),
      child:  AdWidget(ad: _ad!),
    );
  }
}

// ══════════════════════════════════════════════════════════
//  GRADIENT BUTTON
// ══════════════════════════════════════════════════════════
class GradientButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool isLoading;
  final LinearGradient? gradient;

  const GradientButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.isLoading = false,
    this.gradient,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          gradient: gradient ?? primaryGradient,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: AppTheme.primary.withOpacity(0.35),
              blurRadius: 16, offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 22, height: 22,
                  child: CircularProgressIndicator(
                    color: Colors.white, strokeWidth: 2.5,
                  ),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (icon != null) ...[
                      Icon(icon, color: Colors.white, size: 20),
                      const SizedBox(width: 8),
                    ],
                    Text(label,
                      style: const TextStyle(
                        color: Colors.white, fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════
//  PLATFORM CHIP
// ══════════════════════════════════════════════════════════
class PlatformChip extends StatelessWidget {
  final String label;
  final String emoji;
  final bool selected;
  final Color platformColor;
  final VoidCallback onTap;

  const PlatformChip({
    super.key,
    required this.label,
    required this.emoji,
    required this.selected,
    required this.platformColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? platformColor.withOpacity(0.12) : Colors.white,
          border: Border.all(
            color: selected ? platformColor : AppTheme.border,
            width: selected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 16)),
            const SizedBox(width: 6),
            Text(label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                color: selected ? platformColor : AppTheme.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════
//  LENGTH CHIP
// ══════════════════════════════════════════════════════════
class LengthChip extends StatelessWidget {
  final String label;
  final String sublabel;
  final bool selected;
  final VoidCallback onTap;

  const LengthChip({
    super.key,
    required this.label,
    required this.sublabel,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: selected ? AppTheme.primary.withOpacity(0.1) : Colors.white,
          border: Border.all(
            color: selected ? AppTheme.primary : AppTheme.border,
            width: selected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: selected ? AppTheme.primary : AppTheme.textPrimary,
              ),
            ),
            Text(sublabel,
              style: TextStyle(
                fontSize: 11,
                color: selected ? AppTheme.primary.withOpacity(0.7) : AppTheme.textHint,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════
//  CAPTION CARD (used in Saved & History)
// ══════════════════════════════════════════════════════════
class CaptionListCard extends StatelessWidget {
  final String captionText;
  final String platform;
  final String topic;
  final bool isFavorite;
  final DateTime generatedAt;
  final VoidCallback onCopy;
  final VoidCallback onToggleFavorite;
  final VoidCallback? onDelete;

  const CaptionListCard({
    super.key,
    required this.captionText,
    required this.platform,
    required this.topic,
    required this.isFavorite,
    required this.generatedAt,
    required this.onCopy,
    required this.onToggleFavorite,
    this.onDelete,
  });

  Color get _platformColor => switch (platform) {
    'instagram' => AppTheme.instagram,
    'tiktok'    => AppTheme.tiktok,
    'facebook'  => AppTheme.facebook,
    'twitter'   => AppTheme.twitter,
    _           => AppTheme.primary,
  };

  String get _platformLabel => switch (platform) {
    'instagram' => '📸 Instagram',
    'tiktok'    => '🎵 TikTok',
    'facebook'  => '👥 Facebook',
    'twitter'   => '𝕏 Twitter',
    _           => platform,
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.cardShadow,
            blurRadius: 12, offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: _platformColor.withOpacity(0.06),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _platformColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: Text(_platformLabel,
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: _platformColor),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(topic,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                  ),
                ),
                Text(
                  _formatDate(generatedAt),
                  style: const TextStyle(fontSize: 11, color: AppTheme.textHint),
                ),
              ],
            ),
          ),
          // Caption text
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(captionText,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, height: 1.5, color: AppTheme.textPrimary),
            ),
          ),
          // Action row
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Row(
              children: [
                _ActionBtn(icon: Icons.copy_rounded,            onTap: onCopy),
                const SizedBox(width: 8),
                _ActionBtn(
                  icon:  isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  color: isFavorite ? AppTheme.accent : null,
                  onTap: onToggleFavorite,
                ),
                if (onDelete != null) ...[
                  const SizedBox(width: 8),
                  _ActionBtn(icon: Icons.delete_outline_rounded, color: Colors.red.shade300, onTap: onDelete!),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1)  return 'just now';
    if (diff.inHours < 1)    return '${diff.inMinutes}m ago';
    if (diff.inDays < 1)     return '${diff.inHours}h ago';
    if (diff.inDays < 7)     return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final VoidCallback onTap;
  const _ActionBtn({required this.icon, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppTheme.background,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(icon, size: 18, color: color ?? AppTheme.textSecondary),
    ),
  );
}
